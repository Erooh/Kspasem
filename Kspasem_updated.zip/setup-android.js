// Ավտոմատ ավելացնում է ծանուցումների թույլտվությունները AndroidManifest.xml-ում
const fs = require('fs'), path = require('path');
const f = path.join(__dirname, 'android/app/src/main/AndroidManifest.xml');
if (!fs.existsSync(f)) { console.error('Նախ գործարկիր՝ npx cap add android'); process.exit(1); }
let x = fs.readFileSync(f, 'utf8');
const perms = ['POST_NOTIFICATIONS','SCHEDULE_EXACT_ALARM','USE_EXACT_ALARM','RECEIVE_BOOT_COMPLETED','VIBRATE','WAKE_LOCK'];
let add = '';
for (const p of perms) if (!x.includes('android.permission.' + p)) add += '    <uses-permission android:name="android.permission.' + p + '"/>\n';
if (add) x = x.replace('</manifest>', add + '</manifest>');
fs.writeFileSync(f, x);
console.log('Թույլտվությունները ավելացված են');
